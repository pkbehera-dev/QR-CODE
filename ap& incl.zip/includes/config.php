<?php
// ==========================================
// SYSTEM CONFIGURATION
// ==========================================

// 1. Database Credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'qr_serial_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// 2. SMTP Mail Settings (For Forgot Password, 2FA, etc.)
define('SMTP_HOST', 'mail.pkbehera.in');
define('SMTP_PORT', 587);
define('SMTP_USER', 'noreply@pkbehera.in');
define('SMTP_PASS', 'zgMBU{KcEj2p');
define('SMTP_FROM', 'noreply@pkbehera.in');

// 3. reCAPTCHA V2 Invisible Settings
define('RECAPTCHA_SITE_KEY', '6LeQ-1gsAAAAAFHcO8RwhMQezjCg2Ds8JvQAtHt3');
define('RECAPTCHA_SECRET_KEY', '6LeQ-1gsAAAAAJd7M55EDPD_QaL7beww2-xYAvfZ');

// 4. Base URL Configuration
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script_name = $_SERVER['SCRIPT_NAME'] ?? '';
$dir = str_replace('\\', '/', dirname($script_name));
// Ensure spaces and special chars are encoded in URL
$encoded_dir = implode('/', array_map('rawurlencode', explode('/', $dir)));
$base_url = rtrim($protocol . '://' . $host . $encoded_dir, '/');
// Strip subdirectory suffix if present
$base_url = preg_replace('/\/(auth|admin|legal|pages|includes|api)$/i', '', $base_url);
define('BASE_URL', $base_url);
